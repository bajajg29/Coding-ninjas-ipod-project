
function Settings(props) {
  return (
    <div id="settings">
      <div>
        <i className="fas fa-cog"></i>
      </div>
    </div>
  );
}

export default Settings;
  